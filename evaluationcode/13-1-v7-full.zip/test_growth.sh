#!/bin/bash

python3 main.py --outputmode 3 --batch_size 16 --loaddir /mnt/Drive2/ivan_kevin/log/torchimpl/3112-12-56-20-v7-necr-normpet-simplenonorm/epoch49.pt --num_workers 4 --startval 80000 --endval 88000 --gpu 6
