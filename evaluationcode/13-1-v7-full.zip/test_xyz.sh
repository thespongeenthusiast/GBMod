#!/bin/bash

python3 main.py --outputmode 2 --batch_size 16 --loaddir /mnt/Drive2/ivan_kevin/log/torchimpl/0701-09-37-48-v7-necr-normpet-nonorm-batch32-wd05-xyz/epoch48.pt --num_workers 4 --startval 80000 --endval 88000 --gpu 6
