evaluation of:

xyz: 0701-09-37-48 - epoch48.pt (outputmode 2) (as in 13-1 evaluation)
growth: 1401-21-45-28 - epoch50.pt (outputmode 4 -> mu_1, mu_2)


