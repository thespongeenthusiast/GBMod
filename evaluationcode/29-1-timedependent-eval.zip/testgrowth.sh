#!/bin/bash

python3 main.py --outputmode 5 --batch_size 32 --loaddir /mnt/Drive2/ivan_kevin/log/torchimpl/2201-20-14-05-v7_1-necr-normpet-nonorm-batch32-wd05-outputmode5-timedependent/epoch31.pt --num_workers 4 --startval 80000 --endval 88000 --gpu 3
